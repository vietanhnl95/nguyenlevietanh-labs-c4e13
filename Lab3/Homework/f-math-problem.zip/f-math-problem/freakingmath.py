from random import *

def generate_quiz():
    # Hint: Return [x, y, op, result]
    return [0, 0, '@@', 12]

def check_answer(x, y, op, result, user_choice):
    pass
